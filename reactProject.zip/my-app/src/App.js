import React from 'react';
import './App.css';
import { useState,useEffect} from 'react';
import {BrowserRouter as Switch,Router,Route,Link} from 'react-router-dom';
import axios from 'axios';

function App(){
  const [movies,setMovies]=useState([]);
useEffect(()=>{
  axios.get('http://localhost:3001/users')
  .then(response=>setMovies(response.data))
  .catch(error=>{console.log(error)})
},[]);
return(
  <Router>
      <div>
          <nav>
              <ul>
                  <li>
                      <Link to="/">Home</Link>
                  </li>
                  <li>
                      <Link to="/movies">Movies</Link>
                  </li>
              </ul>
          </nav>
          <Switch>
              <Route exact path='/'>
                  <h1>Welcome to my movie path</h1>
              </Route>
              <Route Path='/movies'>
              <div className='card-container'>
                  {movies.map(movie => {
                      <div className='card' key={movie.name}>
                          <h2>{movie.name}</h2>
                          <p>Rating:{movie.rating}</p>
                          <p>Release Date:{movie.releaseDate}</p>
                          </div>
                         })}
              </div>
              </Route>
                 </Switch>
         </div>
</Router>
);
}

export default App;
